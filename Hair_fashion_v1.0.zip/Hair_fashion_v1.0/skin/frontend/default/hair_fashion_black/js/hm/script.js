// JavaScript Document
jQuery.noConflict();
jQuery(document).ready(function(){
	Boxgrid();	
});

function Boxgrid(){
	jQuery('.boxgrid.caption').hover(function(){
		jQuery(".cover", this).stop().animate({top:'120px'},{queue:false,duration:160});
	}, function() {
		jQuery(".cover", this).stop().animate({top:'175px'},{queue:false,duration:160});
	});
}


